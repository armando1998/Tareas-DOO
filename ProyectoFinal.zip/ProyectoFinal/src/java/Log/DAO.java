/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Log;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Slowtown
 */
public class DAO {
    Connection conexion;
    public void abrirConexion() throws SQLException
    {
        String dbURI = "jdbc:derby://localhost:1527/PF";
        String username = "PF";
        String password = "12345gg";
        conexion = DriverManager.getConnection(dbURI, username, password);
        
    }
     private void cerrarConnection() throws SQLException
     {
         conexion.close();
     }
     public void Registrar(POJO pojo)
     {
     try
     {
          abrirConexion();
          String sql ="insert into LOGIN values ('"+pojo.getNombre()+"','"+pojo.getPass()+"')";
          Statement stmt = conexion.createStatement();
          stmt.executeUpdate(sql);
          cerrarConnection();
        }catch (SQLException ex) 
        {
            Logger.getLogger(Autenticacion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     public int Log(POJO pojo)
     {
         int resultados=0;
     try
     {
          abrirConexion();
          //  String sql ="select *" + "from LOGIN where USUARIO='"+pojo.getNombre()+"' and "+ "PASS=like '%"+pojo.getPass()+"%'";
          String sql ="select * from Login where USUARIO='Armando' and PASS='12345'";
          Statement stmt = conexion.createStatement();
          
          ResultSet rs = stmt.executeQuery(sql);
          while(rs.next())
          {
               resultados=1;
            
          }
         
            cerrarConnection();
      }
          
        catch (SQLException ex) 
        {
            Logger.getLogger(Autenticacion.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Ocurrio un error por favor vuelve a intentarlo");
            resultados=0;
            
        }
     return resultados;
    }
     
}
