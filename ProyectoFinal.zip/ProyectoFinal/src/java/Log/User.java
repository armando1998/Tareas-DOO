/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Log;

/**
 *
 * @author Slowtown
 */
public class User {
    private String nombre;
    private String pass;  
    
   public User(String nombre,String pass){
     this.nombre=nombre;
     this.pass=pass;
    }
    
    public String getUsername(){
    return nombre;
    }
}
