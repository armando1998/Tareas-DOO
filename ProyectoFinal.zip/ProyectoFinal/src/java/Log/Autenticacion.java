/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Log;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author Slowtown
 */
public class Autenticacion {
    
    public static boolean authenticate(String username, String password){
           
        DAO log = new DAO();
        POJO pojo = new POJO(); 
        
        pojo.setNombre(username);
        pojo.setPass(password);

        int resultado= log.Log(pojo);
        
            if(resultado==1){
            return true;
        }
        else{
            return false;
        }
        
    }
}
