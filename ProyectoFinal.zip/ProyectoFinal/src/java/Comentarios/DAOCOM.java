/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Comentarios;

import Log.Autenticacion;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.*;
/**
 *
 * @author Slowtown
 */
public class DAOCOM {
     Connection conexion;
    public void abrirConexion() throws SQLException
    {
        String dbURI = "jdbc:derby://localhost:1527/PF";
        String username = "PF";
        String password = "12345gg";
        conexion = DriverManager.getConnection(dbURI, username, password);
        
    }
     private void cerrarConnection() throws SQLException
     {
         conexion.close();
     }
     public void insertar(POJOCOM7 pojo)
     {
         try
         {
             String sql2 = "insert into COMENTARIOS values('"+pojo.getComentarios()+"')";
             Statement stmt = conexion.createStatement();
             stmt.executeUpdate(sql2);
             cerrarConnection();
         }
         catch (SQLException ex) 
        {
            Logger.getLogger(DAOCOM.class.getName()).log(Level.SEVERE, null, ex);
        }
     }
}
